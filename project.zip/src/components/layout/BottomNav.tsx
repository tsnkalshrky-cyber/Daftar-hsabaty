"use client";

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Home, Users, BarChart3, Settings, Archive } from 'lucide-react';
import { cn } from '@/lib/utils';

export function BottomNav() {
  const pathname = usePathname();

  const navItems = [
    { label: 'الرئيسية', icon: Home, href: '/dashboard' },
    { label: 'الحسابات', icon: Users, href: '/accounts' },
    { label: 'التقارير', icon: BarChart3, href: '/reports' },
    { label: 'الأرشيف', icon: Archive, href: '/archive' },
    { label: 'الإعدادات', icon: Settings, href: '/settings' },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-white border-t border-border px-2 flex justify-around items-center h-14 safe-bottom shadow-[0_-2px_10px_rgba(0,0,0,0.03)]">
      {navItems.map((item) => {
        const isActive = pathname.startsWith(item.href);
        const Icon = item.icon;
        
        return (
          <Link
            key={item.href}
            href={item.href}
            className={cn(
              "flex flex-col items-center justify-center space-y-0.5 w-full h-full transition-colors relative",
              isActive ? "text-primary" : "text-muted-foreground"
            )}
          >
            <Icon className={cn("h-5 w-5", isActive && "stroke-[2.5px]")} />
            <span className="text-[9px] font-bold">{item.label}</span>
            {isActive && <div className="h-0.5 w-3 bg-primary rounded-full absolute bottom-1" />}
          </Link>
        );
      })}
    </nav>
  );
}